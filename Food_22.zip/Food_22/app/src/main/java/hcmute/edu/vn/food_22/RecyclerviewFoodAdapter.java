package hcmute.edu.vn.food_22;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class RecyclerviewFoodAdapter extends BaseAdapter {

    private MenuRestaurantActivity mContext;
    private int layout;
    private List<Food> mData;

    public RecyclerviewFoodAdapter(MenuRestaurantActivity mContext,int layout, List<Food> ds) {
        this.mContext = mContext;
        this.layout = layout;
        this.mData = ds;
    }

    @Override
    public int getCount() {
        return mData.size();
    }
    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }
    private class ViewHolder
    {
        TextView tv_food_name, tv_food_price;
        ImageView img_food;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        RecyclerviewFoodAdapter.ViewHolder holder;
        if(convertView==null)
        {
            holder=new RecyclerviewFoodAdapter.ViewHolder();
            LayoutInflater inflater= (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(layout,null);
            holder.tv_food_name = (TextView) convertView.findViewById(R.id.txt_food_name);
            holder.tv_food_price = (TextView) convertView.findViewById((R.id.txt_food_price));
            holder.img_food = (ImageView) convertView.findViewById(R.id.img_food_avatar);
            convertView.setTag(holder);
        }
        else
        {
            holder= (RecyclerviewFoodAdapter.ViewHolder) convertView.getTag();
        }
        final Food info=mData.get(position);
        holder.tv_food_name.setText("info.getFood_name()");
        holder.tv_food_price.setText("info.getPrice()");

        String urlTemp = info.getFood_img();
        Picasso.with(mContext).load(urlTemp).into(holder.img_food);
        return convertView;
    }
}
